// =====================================================================
//  app_timer.h  —  ⏱️ 수업 타이머 신호등  (2차시)
//
//  '남은 시간'을 신호등 색으로 보여 줍니다.
//    초록 = 활동 중 / 노랑 = 곧 끝나요 / 빨강 = 시간 끝 (알림음 + 보드 LED 깜빡)
//  - 위 칸 : 1·3·5·10·15분 중 고르기
//  - 아래 칸: [-1분] [시작·멈춤·계속] [+1분] [처음]  (큰 색 화면을 눌러도 시작·멈춤)
//  - 보드의 BOOT 버튼 = [시작·멈춤] 과 같음 (화면을 안 보고 누를 때)
//
//  ✏️ 바이브코딩으로 바꿔 보기 좋은 곳
//   - PRESET_MIN : 고르는 시간 다섯 개 (분)
//   - YELLOW_AT  : 남은 시간이 전체의 몇 분의 몇이면 노랑이 될지
//   - MSG        : 화면에 나오는 말
//   - 색          : C_GO / C_WAIT / C_STOP (helper.h)
// =====================================================================
#pragma once
#include "helper.h"
#include "sfx.h"

namespace AppTimer {

static Preferences prefs;

// ------------------------------ 설정값 ------------------------------
enum : uint8_t { READY = 0, GREEN = 1, YELLOW = 2, RED = 3 };
static const uint8_t PRESET_MIN[5] = {1, 3, 5, 10, 15};   // 고르는 시간 (분)
static const float   YELLOW_AT     = 0.25f;               // 전체의 1/4 이 남으면 노랑

static const char* MSG[4][2] = {
  {"준비됐어요",   "시작을 눌러 주세요"},
  {"활동 시간",    "집중해서 해 볼까요?"},
  {"곧 끝나요",    "마무리해 주세요"},
  {"시간 끝!",     "모두 멈추고 앞을 봐요"},
};
static const uint16_t STATE_COLOR[4] = { C_BAR, C_GO, C_WAIT, C_STOP };

// ------------------------------ 상태 ------------------------------
static uint16_t totalSec   = 300;       // 전체 시간 (초)
static int32_t  leftMs     = 300000;    // 멈춰 있을 때 남은 시간
static uint32_t endAt      = 0;         // 달리는 중이면 끝나는 시각 (millis)
static bool     running    = false;
static bool     beepOn     = true;
static uint8_t  phase      = READY;
static int      shownSec   = -1;        // 화면에 마지막으로 쓴 초 (바뀔 때만 다시 그림)
static int      pressedBtn = -1;
static uint32_t blinkAt    = 0;
static bool     blinkOn    = false;

static void loadPrefs() {
  prefs.begin("timer", true);
  uint8_t m = prefs.getUChar("min", 5);
  beepOn    = prefs.getBool("beep", true);
  prefs.end();
  if (m < 1 || m > 99) m = 5;
  totalSec = m * 60;
}
static void savePrefs() {
  prefs.begin("timer", false);
  prefs.putUChar("min", totalSec / 60);
  prefs.putBool("beep", beepOn);
  prefs.end();
}

static int32_t remainMs() { return running ? (int32_t)(endAt - millis()) : leftMs; }

static uint8_t phaseNow() {
  int32_t r = remainMs();
  if (!running && r >= (int32_t)totalSec * 1000) return READY;
  if (r <= 0) return RED;
  if (r <= (int32_t)(totalSec * 1000 * YELLOW_AT)) return YELLOW;
  return GREEN;
}

// =====================================================================
//                              그리기
// =====================================================================
// 첫 화면 아이콘: 초시계
static void icon(int cx, int cy) {
  lcd.fillRect(cx - 4, cy - 21, 9, 5, C_BLACK);
  lcd.fillCircle(cx, cy + 3, 17, C_BLACK);
  lcd.fillCircle(cx, cy + 3, 14, C_WHITE);
  lcd.fillArc(cx, cy + 3, 0, 12, 270, 360, C_STOP);       // 남은 시간 조각
  lcd.drawLine(cx, cy + 3, cx, cy - 9, C_BLACK);
}

static uint16_t dim(uint16_t c) {          // 꺼진 신호등 색 (어둡게)
  uint8_t r = ((c >> 11) & 0x1F) << 3, g = ((c >> 5) & 0x3F) << 2, b = (c & 0x1F) << 3;
  return rgb(r / 5, g / 5, b / 5);
}

static void drawBeepButton() {
  button(166, 3, 70, 24, beepOn ? "알림음 켬" : "알림음 끔", beepOn, &fonts::efontKR_12,
         0x4A69, C_WHITE);
}

static void drawLights() {
  lcd.fillRoundRect(30, 48, 180, 48, 24, C_BLACK);
  const uint8_t order[3] = {RED, YELLOW, GREEN};
  for (int i = 0; i < 3; i++) {
    uint8_t s = order[i];
    int cx = 66 + i * 54;
    bool on = (s == phase) && !(s == RED && !blinkOn);
    lcd.fillCircle(cx, 72, 18, on ? STATE_COLOR[s] : dim(STATE_COLOR[s]));
    if (s == phase) lcd.drawCircle(cx, 72, 19, C_WHITE);
  }
}

static void drawTime() {
  int32_t r = remainMs();
  int sec = r > 0 ? (r + 999) / 1000 : 0;     // 남은 초 (올림)
  char b[8];
  snprintf(b, sizeof(b), "%02d:%02d", sec / 60, sec % 60);
  uint16_t bg = STATE_COLOR[phase], ink = (phase == YELLOW) ? C_BLACK : C_WHITE;
  lcd.setFont(&fonts::Font7);
  lcd.setTextSize(1);
  lcd.setTextDatum(textdatum_t::middle_center);
  lcd.setTextColor(ink, bg);
  lcd.setTextPadding(200);
  lcd.drawString(b, 120, 128);
  lcd.setTextPadding(0);
  // 시간이 지나면 몇 초 넘었는지
  if (phase == RED && r < -1000) {
    int over = -r / 1000;
    char m[32];
    if (over < 60) snprintf(m, sizeof(m), "%d초 지났어요", over);
    else           snprintf(m, sizeof(m), "%d분 %d초 지났어요", over / 60, over % 60);
    lcd.fillRect(0, 192, 240, 22, bg);
    text(m, 120, 203, &fonts::efontKR_16, ink);
  }
}

static void drawPanel() {
  uint16_t bg = STATE_COLOR[phase];
  uint16_t ink = (phase == YELLOW) ? C_BLACK : C_WHITE;
  lcd.startWrite();
  lcd.fillRect(0, 30, 240, 192, bg);
  char m[32];
  const char* st = running ? "" : (phase == READY ? " · 준비" : " · 멈춤");
  snprintf(m, sizeof(m), "%d분 타이머%s", totalSec / 60, st);
  text(m, 8, 39, &fonts::efontKR_12, ink, textdatum_t::middle_left);
  drawLights();
  shownSec = -1;
  drawTime();
  text(MSG[phase][0], 120, 172, &fonts::efontKR_24_b, ink);
  if (!(phase == RED && remainMs() < -1000)) text(MSG[phase][1], 120, 203, &fonts::efontKR_16, ink);
  lcd.endWrite();
}

static void drawBar() {
  const int bx = 36, bw = 196, by = 228, bh = 14;
  lcd.fillRect(0, 222, 240, 26, C_BG);
  text("남은", 4, by + 7, &fonts::efontKR_12, C_WHITE, textdatum_t::middle_left);
  lcd.fillRect(bx, by, bw, bh, 0x2104);
  float f = constrain(remainMs() / (totalSec * 1000.0f), 0.0f, 1.0f);
  int w = (int)(bw * f);
  if (w > 0) lcd.fillRect(bx, by, w, bh, phase == READY ? C_GO : STATE_COLOR[phase]);
  int xy = bx + (int)(bw * YELLOW_AT);
  lcd.fillRect(xy, by - 3, 2, bh + 6, C_WAIT);                 // 노랑이 되는 곳
  lcd.drawRect(bx, by, bw, bh, C_DARK);
}

static const char* mainLabel() {
  if (running) return phase == RED ? "다시" : "멈춤";
  return phase == READY ? "시작" : (phase == RED ? "다시" : "계속");
}

static void drawPresets() {
  lcd.fillRect(0, 248, 240, 34, C_BG);
  for (int i = 0; i < 5; i++) {
    char b[8]; snprintf(b, sizeof(b), "%d분", PRESET_MIN[i]);
    button(4 + i * 47, 250, 43, 28, b, totalSec == PRESET_MIN[i] * 60, &fonts::efontKR_16);
  }
}

static const int BX[4] = {4, 60, 128, 184}, BW[4] = {52, 64, 52, 52};
static void drawButtons() {
  lcd.fillRect(0, 282, 240, 38, C_BG);
  button(BX[0], 286, BW[0], 30, "-1분");
  button(BX[1], 286, BW[1], 30, mainLabel(), true);
  button(BX[2], 286, BW[2], 30, "+1분");
  button(BX[3], 286, BW[3], 30, "처음", false, &fonts::efontKR_16, 0x4A69, C_WHITE);
}

static void drawAll() {
  lcd.startWrite();
  lcd.fillScreen(C_BG);
  drawTitleBar("타이머 신호등");
  drawBeepButton();
  drawPresets();
  drawButtons();
  lcd.endWrite();
  drawPanel();
  drawBar();
}

// =====================================================================
//                              동작
// =====================================================================
static void setLed() {
  if (phase == RED)         rgbLedWrite(PIN_WS2812, blinkOn ? 120 : 0, 0, 0);
  else if (phase == YELLOW) rgbLedWrite(PIN_WS2812, 90, 60, 0);
  else if (phase == GREEN)  rgbLedWrite(PIN_WS2812, 0, 60, 0);
  else                      rgbLedWrite(PIN_WS2812, 0, 0, 0);
}

static void refresh() {               // 단계가 바뀌었을 수 있으니 전부 다시
  phase = phaseNow();
  blinkOn = true; blinkAt = millis();
  drawPanel(); drawBar(); drawButtons(); setLed();
}

static void reset() {                 // 처음으로 (같은 시간)
  running = false;
  leftMs = (int32_t)totalSec * 1000;
  refresh();
}

static void startPause() {
  if (phaseNow() == RED) {            // 끝난 뒤 → 같은 시간으로 다시 시작
    leftMs = (int32_t)totalSec * 1000;
    endAt = millis() + leftMs; running = true;
  } else if (running) {
    leftMs = remainMs(); running = false;
  } else {
    endAt = millis() + leftMs; running = true;
  }
  refresh();
}

static void addMinute(int d) {
  int32_t r = remainMs();
  if (d < 0 && (totalSec <= 60 || r <= 60000 + 5000)) { Sfx::play(SFX_ERROR); return; }
  if (d > 0 && totalSec >= 99 * 60) { Sfx::play(SFX_ERROR); return; }
  if (phaseNow() == RED) { reset(); }               // 끝난 뒤에 누르면 처음부터
  totalSec += d * 60;
  if (running) endAt += d * 60000; else leftMs += d * 60000;
  savePrefs();
  drawPresets();
  refresh();
}

// =====================================================================
//                     앱 규칙 4가지 (교탁 도우미가 부름)
// =====================================================================
static void start() {
  static bool loaded = false;
  if (!loaded) { loadPrefs(); leftMs = (int32_t)totalSec * 1000; loaded = true; }
  pressedBtn = -1;
  phase = phaseNow();
  blinkOn = true;
  drawAll();
  setLed();
}

static void update() {
  uint32_t now = millis();
  uint8_t p = phaseNow();
  if (p != phase) {
    bool toRed = (p == RED), toYellow = (p == YELLOW && phase == GREEN);
    phase = p;
    blinkOn = true; blinkAt = now;
    drawPanel(); drawButtons(); setLed();
    if (beepOn && toRed)    Sfx::play(SFX_ALARM);
    if (beepOn && toYellow) Sfx::play(SFX_CHORD);
  }
  int32_t r = remainMs();
  int sec = r > 0 ? (r + 999) / 1000 : -((-r) / 1000) - 1;
  if (sec != shownSec) {
    shownSec = sec;
    lcd.startWrite(); drawTime(); lcd.endWrite();
    drawBar();
  }
  if (phase == RED && now - blinkAt >= 500) {        // 빨강은 깜빡깜빡
    blinkAt = now; blinkOn = !blinkOn;
    lcd.startWrite(); drawLights(); lcd.endWrite();
    setLed();
  }
}

static int presetAt(int x, int y) {
  if (y < 248 || y >= 282) return -1;
  return constrain((x - 4) / 47, 0, 4);
}
static int buttonAt(int x, int y) {
  if (y < 284) return -1;
  for (int i = 3; i >= 0; i--) if (x >= BX[i] - 2) return i;
  return 0;
}

static void touch(uint8_t ev, int x, int y) {
  if (ev == TOUCH_DOWN) {
    pressedBtn = buttonAt(x, y);
    if (pressedBtn >= 0) buttonPressed(BX[pressedBtn], 286, BW[pressedBtn], 30);
    return;
  }
  if (ev != TOUCH_UP) return;

  if (inside(x, y, 166, 0, 74, 30)) {                // 알림음 켜고 끄기
    beepOn = !beepOn; savePrefs(); drawBeepButton();
    Sfx::play(SFX_TAP);
    return;
  }
  if (y >= 30 && y < 222) {                          // 큰 화면 아무 데나 = 시작·멈춤
    Sfx::play(SFX_TAP); startPause();
    return;
  }
  int pr = presetAt(x, y);
  if (pr >= 0) {                                     // 시간 고르기 → 처음 상태로
    totalSec = PRESET_MIN[pr] * 60;
    savePrefs();
    Sfx::play(SFX_TAP);
    drawPresets();
    reset();
    return;
  }
  int b = buttonAt(x, y);
  int was = pressedBtn;
  pressedBtn = -1;
  if (b < 0 || b != was) { drawButtons(); return; }
  Sfx::play(SFX_TAP);
  switch (b) {
    case 0: addMinute(-1); break;
    case 1: startPause();  break;
    case 2: addMinute(+1); break;
    case 3: reset();       break;
  }
  drawButtons();
}

static void bootButton() { Sfx::play(SFX_TAP); startPause(); }

static void stop() {
  rgbLedWrite(PIN_WS2812, 0, 0, 0);    // 나갈 때 LED 끄기 (타이머는 멈추지 않고 계속 흘러요)
  savePrefs();
}

const App app = {
  "타이머 신호등", "남은 시간을 색으로 보여요", C_NOISE, icon,
  start, update, touch, stop,
  bootButton, // BOOT 버튼 = 시작·멈춤
  true,       // 화면이 계속 보여야 하니 자동으로 어두워지지 않음
  true        // 완성!
};

}  // namespace AppTimer
