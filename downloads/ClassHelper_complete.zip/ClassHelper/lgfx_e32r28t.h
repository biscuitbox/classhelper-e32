// =====================================================================
//  lgfx_e32r28t.h  —  E32R28T-1 화면 설정 (ST7789 + XPT2046 저항식 터치)
//  
// =====================================================================
#pragma once
#define LGFX_USE_V1
#include <LovyanGFX.hpp>
#include "config.h"

class LGFX : public lgfx::LGFX_Device {
  lgfx::Panel_ST7789  _panel;
  lgfx::Bus_SPI       _bus;
  lgfx::Light_PWM     _light;
  lgfx::Touch_XPT2046 _touch;

public:
  LGFX() {
    {
      auto cfg = _bus.config();
      cfg.spi_host    = SPI2_HOST;       // 화면은 HSPI (터치는 따로 VSPI)
      cfg.spi_mode    = 0;
      cfg.freq_write  = 40000000;
      cfg.freq_read   = 16000000;
      cfg.spi_3wire   = false;
      cfg.use_lock    = true;
      cfg.dma_channel = SPI_DMA_CH_AUTO;
      cfg.pin_sclk    = PIN_LCD_SCK;
      cfg.pin_mosi    = PIN_LCD_MOSI;
      cfg.pin_miso    = PIN_LCD_MISO;
      cfg.pin_dc      = PIN_LCD_DC;
      _bus.config(cfg);
      _panel.setBus(&_bus);
    }
    {
      auto cfg = _panel.config();
      cfg.pin_cs          = PIN_LCD_CS;
      cfg.pin_rst         = -1;          // EN 과 공용
      cfg.pin_busy        = -1;
      cfg.panel_width     = 240;
      cfg.panel_height    = 320;
      cfg.offset_x        = 0;
      cfg.offset_y        = 0;
      cfg.offset_rotation = LCD_OFFSET_ROTATION;
      cfg.readable        = true;
      cfg.invert          = LCD_INVERT;  // TN 패널: 보통 반전 없음
      cfg.rgb_order       = LCD_BGR;
      cfg.dlen_16bit      = false;
      cfg.bus_shared      = false;
      _panel.config(cfg);
    }
    {
      auto cfg = _light.config();
      cfg.pin_bl      = PIN_LCD_BL;
      cfg.invert      = false;
      cfg.freq        = 12000;
      cfg.pwm_channel = 7;
      _light.config(cfg);
      _panel.setLight(&_light);
    }
    {
      auto cfg = _touch.config();
      cfg.x_min = 0;  cfg.x_max = 4095;  // 실제 위치 맞추기는 touch_xpt2046.h 의 '터치 보정'이 함
      cfg.y_min = 0;  cfg.y_max = 4095;
      cfg.pin_int    = PIN_TP_INT;
      cfg.bus_shared = false;
      cfg.offset_rotation = 0;
      cfg.spi_host = SPI3_HOST;          // VSPI
      cfg.freq     = 1000000;
      cfg.pin_sclk = PIN_TP_SCK;
      cfg.pin_mosi = PIN_TP_MOSI;
      cfg.pin_miso = PIN_TP_MISO;
      cfg.pin_cs   = PIN_TP_CS;
      _touch.config(cfg);
      _panel.setTouch(&_touch);
    }
    setPanel(&_panel);
  }
};
