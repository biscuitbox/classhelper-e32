// =====================================================================
//  config.h  —  기기 이름 · 보드 핀 설정
//
//  이 코드는 LCDwiki E32R28T-1 (ESP32 2.8인치 저항식 터치, 라벨에 SKU:E32R28T-1) 전용입니다.
//  아두이노 IDE: Tools → Board 는 "ESP32 Dev Module"
//
//  ✏️ 선생님이 바꿔도 되는 곳은 "기기 이름" 세 줄과 시계 와이파이 세 줄뿐입니다.
//     나머지는 보드 배선이라 건드리지 마세요.
// =====================================================================
#pragma once
#include <sdkconfig.h>

#define BOARD_E32R28T  1     // 보드 종류 (바꾸지 마세요)

// Tools → Board 가 맞는지 검사 (틀리면 빨간 오류로 알려 줌)
#if !defined(CONFIG_IDF_TARGET_ESP32)
  #error "Tools -> Board 를 ESP32 Dev Module 로 바꾸세요. (ESP32S3 Dev Module 이 아닙니다)"
#endif

// ---------- ✏️ 기기 이름 — 마음대로 바꿔도 돼요 (큰따옴표 " " 안만) ----------
// 글자가 길면 화면에서 저절로 작게 써요. 한글 OK, 이모지는 화면에 안 나와요.
#define DEVICE_TITLE   "교탁 도우미"        // 첫 화면 큰 제목 — 한글 12자까지 (8자 안쪽이 크게 보여요)
#define DEVICE_OWNER   "2학년 3반"          // 첫 화면·시계에 작게 — 한글 18자까지 (반 이름, 선생님 이름 등)
#define BT_NAME        "ClassHelper-01"     // 블루투스 이름 — 영어·숫자·- 로 16자까지, 다른 조와 겹치지 않게!
// 글자 수 검사 (한글 1자 = 3칸, 영어·숫자·띄어쓰기 1자 = 1칸으로 셈)
static_assert(sizeof(DEVICE_TITLE) <= 37, "config.h: DEVICE_TITLE 은 한글 12자(영어 36자)까지만 써 주세요");
static_assert(sizeof(DEVICE_OWNER) <= 55, "config.h: DEVICE_OWNER 는 한글 18자(영어 54자)까지만 써 주세요");
static_assert(sizeof(BT_NAME) <= 17, "config.h: BT_NAME 은 영어·숫자 16자까지만 써 주세요 (길면 PC 목록에 안 보여요)");

// ---------- ✏️ 탁상시계: 인터넷으로 시간 맞추기 (안 써도 됨) ----------
// 와이파이가 있으면 1 로 바꾸고 이름·비밀번호를 적으세요. 0 이면 시계 화면에서 손으로 맞춥니다.
// (학교 와이파이처럼 로그인 화면이 뜨는 곳은 안 됩니다. 휴대폰 핫스팟은 됩니다.)
#define CLOCK_WIFI     0
#define WIFI_SSID      ""
#define WIFI_PASS      ""

// ---------- LCD (SPI, ST7789) ----------
#define PIN_LCD_SCK    14
#define PIN_LCD_MOSI   13
#define PIN_LCD_MISO   12
#define PIN_LCD_CS     15
#define PIN_LCD_DC      2
#define PIN_LCD_BL     21     // HIGH = 백라이트 켜짐
// LCD 리셋은 ESP32 EN(리셋)과 공용이라 따로 핀이 없음

// 화면이 좌우로 뒤집혀(거울처럼) 보이면 0 -> 6 으로 바꾸세요.
#define LCD_OFFSET_ROTATION  0
#define LCD_INVERT     0      // 색이 사진 필름처럼 뒤집혀 보이면(검정 바탕이 흰색) 1 로
#define LCD_BGR        0      // 빨강과 파랑이 서로 바뀌어 보이면 1 로

// ---------- 터치 (SPI, XPT2046 저항식) ----------
//  손톱이나 펜 끝으로 '꾹' 눌러야 합니다. 처음 켤 때 네 귀퉁이를 눌러 위치를 맞춰요(터치 보정).
//  다시 맞추려면: 설정 → 점검 → [터치 보정], 또는 켜고 5초 안에 BOOT 를 1초 누르기
#define PIN_TP_SCK     25
#define PIN_TP_MOSI    32
#define PIN_TP_MISO    39
#define PIN_TP_CS      33
#define PIN_TP_INT     36     // 누르면 LOW (절전에서 깨우는 데도 씀)
#define TOUCH_Y_OFFSET  0

// ---------- 오디오 (ESP32 DAC + FM8002E 앰프) ----------
#define PIN_DAC        26     // 스피커 소리 (DAC 2번)
#define PIN_AMP_EN      4
#define AMP_ON_LEVEL    LOW   // 제조사 문서: Low = 앰프 켜짐
#define AUDIO_SAMPLE_RATE 22050

// ---------- 기타 ----------
#define PIN_LED_R      22     // 보드 RGB LED (LOW = 켜짐)
#define PIN_LED_G      16
#define PIN_LED_B      17
#define PIN_WS2812     255    // 앱에서 rgbLedWrite(PIN_WS2812, …) 로 쓰는 이름 (위 세 핀으로 바꿔서 켬)
#define PIN_BAT_ADC    34     // 배터리 전압 (1/2 분압)
#define BAT_DIVIDER   2.0f
#define PIN_BOOT_BTN    0     // BOOT 버튼 (앱마다 쓰임이 다름)

// 이 보드에 있는 것 / 없는 것
#define HAS_MIC         0     // 마이크 없음 (2차시는 '타이머 신호등' app_timer.h)
#define HAS_I2C         0     // 시계 모듈(DS3231)은 연결하지 않음


// ---------- 공통 조작 ----------
#define LONG_PRESS_MS  380    // 길게 누르기 판정 시간 (지뢰찾기 깃발)
#define HOME_HOLD_MS   700    // 왼쪽 위 🏠 를 이만큼 누르고 있으면 첫 화면으로
